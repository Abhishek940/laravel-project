<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
<div class="col-md-3">
</div>
<div class="col-md-6">
<h2 style="text-align:center">Login </h2>
<form method="post" action="/loginsubmit">
<?php echo csrf_field(); ?>
<div class="form-group">
<label>User Name</label>
<input type="text" name="email" class="form-control" placeholder="Enter Username" required>
</div>
<div class="form-group">
<label>Password</label>
<input type="text" name="password" class="form-control" placeholder="Enter Password" required>
</div>
<div class="form-group">
<button type="submit" class="btn btn-danger">Submit</button>
</div>
</form>
</div>
<div class="col-md-3"></div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel project\project\resources\views/login.blade.php ENDPATH**/ ?>