<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="uper">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
  <?php endif; ?>
  <div class="container">
  <table class="table table-striped">
    <thead>
        <tr>
          <td>S.no</td>
          <td>Name</td>
		  <td>Mobile No.</td>
          <td>Email Id</td>
          <td>Password</td>
		  <td>Image</td>
          <td>Update</td>
		  <td>Delete</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>		    
            <td><?php echo e($row->name); ?></td>
			<td><?php echo e($row->mobile); ?></td>
            <td><?php echo e($row->email); ?></td>
            <td><?php echo e($row->password); ?></td>
			 <td><img src="<?php echo e(url('images/'.$row->image)); ?>" style="height:75px;width:80px"/></td>
            <td><a href="/edit-user/<?php echo e($row->id); ?>" class="btn btn-success">Update</td>
            <form method="post" action="/delete-user/<?php echo e($row->id); ?>">
					  <?php echo e(csrf_field()); ?>

					  <?php echo e(method_field('delete')); ?>

				  
				  <td><button type="submit"class="btn btn-danger" >Delete</button>
				  </form>
        </tr>
		
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
    </tbody>
  </table>
  <div class="container">
					<div class="row">
					<div class="col-md-3"></div>
					<div class="col-md-9">
					<?php echo e($user->links()); ?>

					</div>
					<div class="col-md-9"></div>
					</div>
				 	</div>
  </div>
<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel project\project\resources\views/user-list.blade.php ENDPATH**/ ?>